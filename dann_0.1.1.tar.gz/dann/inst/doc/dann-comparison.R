## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----covariance-example-------------------------------------------------------
library(dann)
set.seed(42)

n <- 150

# Class 1: elongated horizontally (high variance in x, low in y)
class1_x <- rnorm(n, mean = 0, sd = 2.0)
class1_y <- rnorm(n, mean = 0, sd = 0.4)

# Class 2: elongated vertically (low variance in x, high in y)
class2_x <- rnorm(n, mean = 0, sd = 0.4)
class2_y <- rnorm(n, mean = 0, sd = 2.0)

# Combine
x <- rbind(
  cbind(class1_x, class1_y),
  cbind(class2_x, class2_y)
)
y <- c(rep(1L, n), rep(2L, n))

# Shuffle
idx <- sample(2 * n)
x <- x[idx, ]
y <- y[idx]

# Split train/test
train_idx <- 1:240
test_idx <- 241:300

x_train <- x[train_idx, ]
x_test <- x[test_idx, ]
y_train <- y[train_idx]
y_test <- y[test_idx]

# Standardize
std <- stand(x_train, x_test)

# Compare methods
knn_pred <- knn(std$x, std$xx, y_train, k = 5)
dann_pred <- dann(std$x, std$xx, y_train, k = 5, kmetric = 40, fullw = TRUE)

knn_acc <- mean(knn_pred == y_test)
dann_acc <- mean(dann_pred == y_test)

cat("5-NN accuracy: ", round(knn_acc * 100, 1), "%\n", sep = "")
cat("DANN accuracy: ", round(dann_acc * 100, 1), "%\n", sep = "")

## ----noise-example------------------------------------------------------------
set.seed(123)
n <- 150

# 2 informative features: classes separated
x_informative <- rbind(
  matrix(rnorm(n * 2, mean = 0, sd = 0.5), n, 2),
  matrix(rnorm(n * 2, mean = 2, sd = 0.5), n, 2)
)

# 8 noise features: pure random, no class information
x_noise <- matrix(rnorm(2 * n * 8, sd = 1), 2 * n, 8)

x <- cbind(x_informative, x_noise)
y <- c(rep(1L, n), rep(2L, n))

# Shuffle and split
idx <- sample(2 * n)
x <- x[idx, ]
y <- y[idx]

train_idx <- 1:240
test_idx <- 241:300

# Standardize
std <- stand(x[train_idx, ], x[test_idx, ])

# Compare
knn_pred <- knn(std$x, std$xx, y[train_idx], k = 5)
dann_pred <- dann(std$x, std$xx, y[train_idx], k = 5, kmetric = 40, fullw = TRUE)

knn_acc <- mean(knn_pred == y[test_idx])
dann_acc <- mean(dann_pred == y[test_idx])

cat("With 8 noise features:\n")
cat("5-NN accuracy: ", round(knn_acc * 100, 1), "%\n", sep = "")
cat("DANN accuracy: ", round(dann_acc * 100, 1), "%\n", sep = "")

## ----glass-example------------------------------------------------------------
data(dannt)

# Standardize
std <- stand(glass.train$x, glass.test$x)

# Methods
knn_pred <- knn(std$x, std$xx, glass.train$y, k = 5)
dann_pred <- dann(std$x, std$xx, glass.train$y, k = 5, kmetric = 50)

knn_errors <- sum(knn_pred != glass.test$y)
dann_errors <- sum(dann_pred != glass.test$y)

n_test <- length(glass.test$y)

cat("Glass dataset (", n_test, " test samples, 6 classes):\n", sep = "")
cat("5-NN errors: ", knn_errors, " (", round(100 * knn_errors / n_test, 1), "%)\n", sep = "")
cat("DANN errors: ", dann_errors, " (", round(100 * dann_errors / n_test, 1), "%)\n", sep = "")

## ----epsilon-example----------------------------------------------------------
data(dannt)
std <- stand(glass.train$x, glass.test$x)

# Try different epsilon values
epsilons <- c(0.1, 1, 10)
results <- dann(std$x, std$xx, glass.train$y, k = 5, kmetric = 50, epsilon = epsilons)

for (i in seq_along(epsilons)) {
  errors <- sum(results[, i] != glass.test$y)
  cat("epsilon =", epsilons[i], "-> errors:", errors, "\n")
}

